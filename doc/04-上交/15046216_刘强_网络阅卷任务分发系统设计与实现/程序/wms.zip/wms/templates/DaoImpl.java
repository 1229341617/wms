package ${basePkg}.dao.impl;

import ${basePkg}.dao.${className}Dao;
import ${basePkg}.domain.${className};

public class ${className}DaoImpl extends GenericDaoImpl<${className}> implements ${className}Dao{
	
}
