package ${basePkg}.dao;

import ${basePkg}.domain.${className};

public interface ${className}Dao extends GenericDao<${className}>{
	
}
