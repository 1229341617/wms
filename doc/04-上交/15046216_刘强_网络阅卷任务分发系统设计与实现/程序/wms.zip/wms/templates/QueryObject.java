package ${basePkg}.query;

public class ${className}QueryObject extends QueryObject{
	@Override
	public void customizedQuery() {
		//TODO
	}
	
}
