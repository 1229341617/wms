package com._520it.wms.dao;

import com._520it.wms.domain.Subject;

public interface SubjectDao extends GenericDao<Subject>{
	
}
