package com._520it.wms.dao.impl;

import com._520it.wms.dao.RoleDao;
import com._520it.wms.domain.Role;

public class RoleDaoImpl extends GenericDaoImpl<Role> implements RoleDao{
	
}
