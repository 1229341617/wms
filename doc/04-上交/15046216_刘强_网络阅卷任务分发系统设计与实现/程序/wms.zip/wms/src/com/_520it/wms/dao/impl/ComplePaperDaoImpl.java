package com._520it.wms.dao.impl;

import com._520it.wms.dao.ComplePaperDao;
import com._520it.wms.domain.ComplePaper;

public class ComplePaperDaoImpl extends GenericDaoImpl<ComplePaper> implements ComplePaperDao{
	
}
