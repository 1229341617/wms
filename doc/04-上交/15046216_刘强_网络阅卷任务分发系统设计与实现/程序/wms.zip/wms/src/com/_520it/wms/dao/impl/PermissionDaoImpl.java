package com._520it.wms.dao.impl;

import com._520it.wms.dao.PermissionDao;
import com._520it.wms.domain.Permission;

public class PermissionDaoImpl extends GenericDaoImpl<Permission> implements PermissionDao{

}
