package com._520it.wms.query;

public class ComplePaperQueryObject extends QueryObject{
	@Override
	public void customizedQuery() {
		//TODO
	}
	
}
