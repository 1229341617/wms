package com._520it.wms.util;

public class StrUtil {
	public static Boolean hasLength(String str){
		return str != null && !"".equals(str.trim());
	}
}
