package com._520it.wms.dao;

import com._520it.wms.domain.ComplePaper;

public interface ComplePaperDao extends GenericDao<ComplePaper>{
	
}
