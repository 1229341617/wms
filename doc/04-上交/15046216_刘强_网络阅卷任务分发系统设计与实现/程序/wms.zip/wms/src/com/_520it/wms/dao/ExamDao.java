package com._520it.wms.dao;

import com._520it.wms.domain.Exam;

public interface ExamDao extends GenericDao<Exam>{
	
}
