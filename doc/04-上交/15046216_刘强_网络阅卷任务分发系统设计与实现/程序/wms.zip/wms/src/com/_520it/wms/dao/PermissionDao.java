package com._520it.wms.dao;

import com._520it.wms.domain.Permission;

public interface PermissionDao extends GenericDao<Permission>{

}
