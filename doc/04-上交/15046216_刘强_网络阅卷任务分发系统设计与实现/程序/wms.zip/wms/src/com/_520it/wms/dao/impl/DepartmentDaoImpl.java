package com._520it.wms.dao.impl;

import com._520it.wms.dao.DepartmentDao;
import com._520it.wms.domain.Department;

public class DepartmentDaoImpl extends GenericDaoImpl<Department> implements DepartmentDao{
}
