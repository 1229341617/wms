package com._520it.wms.domain;

public interface IJsonObject {
	Object toJson();
}
