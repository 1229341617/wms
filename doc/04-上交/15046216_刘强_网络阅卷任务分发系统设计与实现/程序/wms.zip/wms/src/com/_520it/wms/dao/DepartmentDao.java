package com._520it.wms.dao;

import com._520it.wms.domain.Department;


public interface DepartmentDao extends GenericDao<Department>{
}
