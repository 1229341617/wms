package com._520it.wms.dao;

import com._520it.wms.domain.Role;

public interface RoleDao extends GenericDao<Role>{

}
