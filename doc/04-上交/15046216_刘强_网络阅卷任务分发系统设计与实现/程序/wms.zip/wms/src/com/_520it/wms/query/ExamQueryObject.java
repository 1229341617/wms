package com._520it.wms.query;

public class ExamQueryObject extends QueryObject{
	@Override
	public void customizedQuery() {
		//TODO
	}
	
}
