package com._520it.wms.dao.impl;

import com._520it.wms.dao.ExamDao;
import com._520it.wms.domain.Exam;

public class ExamDaoImpl extends GenericDaoImpl<Exam> implements ExamDao{
	
}
