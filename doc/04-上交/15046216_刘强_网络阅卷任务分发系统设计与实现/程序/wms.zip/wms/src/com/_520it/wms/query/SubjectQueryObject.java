package com._520it.wms.query;

public class SubjectQueryObject extends QueryObject{
	@Override
	public void customizedQuery() {
		//TODO
	}
	
}
