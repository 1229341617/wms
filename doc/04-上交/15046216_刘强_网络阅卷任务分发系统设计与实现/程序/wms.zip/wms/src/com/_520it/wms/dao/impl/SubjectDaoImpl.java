package com._520it.wms.dao.impl;

import com._520it.wms.dao.SubjectDao;
import com._520it.wms.domain.Subject;

public class SubjectDaoImpl extends GenericDaoImpl<Subject> implements SubjectDao{
	
}
